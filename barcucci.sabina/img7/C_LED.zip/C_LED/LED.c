// LED 
#include <avr/io.h>
#include <util/delay.h>


int main()
{
	//SETUP
	//LED is PB2


	DDRA = _BV(PA7); //Enable output on the LED pin
	PORTA = _BV(PA7); //Turns LED on

}


