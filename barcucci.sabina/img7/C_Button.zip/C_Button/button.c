#include <avr/io.h>
#include <util/delay.h>

#define TRUE 1
#define FALSE 0

int main()
{
//SETUP
//Button is on PA3
//LED is PA7

PORTA|= _BV(PA3); //Turn button pullup resistor on
DDRB = _BV(PA7); //Enable output on the LED pin
//PORTB = _BV(PB2); //Turns LED on

//LOOP
while (TRUE)
{
if ((PINA & _BV(PA3))) //button is not pushed
{
PORTA &= ~ (_BV(PA7)); //turn LED off
}
else 
{
PORTA |= _BV(PA7); //turn LED on
_delay_ms(10);
PORTA &= ~(_BV(PA7));
_delay_ms(100);
}
}
}
